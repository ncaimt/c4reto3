package reto3.Application.Test;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
/**
 * 
 * @author dario
 */
@SpringBootTest
class Reto3ApplicationTest {
	@Test
	void contextLoads() {
	}
}
