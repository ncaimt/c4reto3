package reto3.backend.Applications;
import reto3.backend.models.Laptop;
import reto3.backend.models.Order;
import reto3.backend.models.User;
import reto3.backend.repository.crud.OrderCrudRepository;
import reto3.backend.repository.crud.UserCrudRepository;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import reto3.backend.repository.crud.LaptopCrudRepository;
/**
 * 
 * @author dario
 */
@SpringBootApplication
public class RetotresApplication implements CommandLineRunner {
    @Autowired
    private LaptopCrudRepository crudRepository;
    @Autowired
    private UserCrudRepository userCrudRepository;
    @Autowired
    private OrderCrudRepository orderCrudRepository;
    /**
     * 
     * @param args 
     */
    public static void main(String[] args) {
        SpringApplication.run(RetotresApplication.class, args);
    }
    /**
     * 
     * @param args
     * @throws Exception 
     */
    @Override
    public void run(String... args) throws Exception {
        SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        crudRepository.deleteAll();
        userCrudRepository.deleteAll();
        orderCrudRepository.deleteAll();
        System.out.println("Listado de ordenes");
        orderCrudRepository.findAll().forEach(System.out::println);             
    }
}
