package reto3.backend;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
/**
 * **
 * @author dario
 */
@SpringBootTest
class Reto3ApplicationTests {

	@Test
	void contextLoads() {
	}
}
